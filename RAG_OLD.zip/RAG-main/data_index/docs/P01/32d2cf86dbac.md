# Lenovo ThinkBook 15 AMD Ryzen 5 5500U 15.6" (39.62cm) FHD 220 nits Antiglare Thin and Light Laptop (8GB/512GB SSD/Windows 11/MS Office/Mineral Grey/1.7 Kg), 21A4A09UIH

doc_id: 32d2cf86dbac
row: 25
price: 45990.0
rating: 3.9

## Content
ROW=25 | MODEL=Lenovo ThinkBook 15 AMD Ryzen 5 5500U 15.6" (39.62cm) FHD 220 nits Antiglare Thin and Light Laptop (8GB/512GB SSD/Windows 11/MS Office/Mineral Grey/1.7 Kg), 21A4A09UIH | PRICE=45990.0 | RATING=3.9 | RATINGS=83.0 | DIMS=23.5 x 35.7 x 1.9 Centimeters. 22,087 in Electronics (See Top 100 in Electronics) 220 in Traditional Laptops 1 Case Laptop