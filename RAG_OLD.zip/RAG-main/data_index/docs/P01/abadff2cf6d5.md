# Honor MagicBook 15, AMD Ryzen 5 5500U 15.6-inch (39.62 cm) FHD IPS Anti-Glare Thin and Light Laptop (8GB/256GB PCIe SSD/Windows 11/ Metal Body/Fingerprint Login/1.54Kg), Gray, BohrM-WDQ9CHNE

doc_id: abadff2cf6d5
row: 53
price: 39490.0
rating: 4.3

## Content
ROW=53 | MODEL=Honor MagicBook 15, AMD Ryzen 5 5500U 15.6-inch (39.62 cm) FHD IPS Anti-Glare Thin and Light Laptop (8GB/256GB PCIe SSD/Windows 11/ Metal Body/Fingerprint Login/1.54Kg), Gray, BohrM-WDQ9CHNE | PRICE=39490.0 | RATING=4.3 | RATINGS=479.0 | DIMS=17 x 230 x 357 Millimeters. 2,805 in Electronics (See Top 100 in Electronics) 15 in Traditional Laptops 1 Count Laptop